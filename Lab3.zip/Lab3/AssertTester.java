//Name:Ajit Pandey
//USC NetID:ajitpand
//CSCI 455 Fall 2019
//Lab 5

public class AssertTester {

	public static void main(String[] args) {
		
		Term termTest = new Term(1.2, 1);
		Term termTest1 = new Term (1.6, -2);
		System.out.println(termTest.toString());
		System.out.println(termTest1.toString());
	}

}